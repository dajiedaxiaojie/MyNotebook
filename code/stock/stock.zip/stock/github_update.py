import sys

from github import Github
from t import format_trade_info, tidy_web_data
# from history import msg


class MyNotebookGithubUpdate:
    def __init__(self):
        # 访问令牌
        token = "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"
        # 连接到 GitHub
        g = Github(token)
        # 获取仓库
        self.repo = g.get_repo("dajiedaxiaojie/MyNotebook")

    def update_me_md(self, file_path, content, message="Update file"):
        title = '''|stock|code|time_in|price_in|rate_in|time_out|price_out|rate_out|person|\n|---|---|---|---|---|---|---|---|---|\n'''
        file = self.repo.get_contents(file_path)
        msg_github = file.decoded_content.decode().replace(title, '')
        content_tidy = tidy_web_data(data=msg_github + '\n' + content)
        new_content = title + content_tidy
        print('Update:\n', new_content)
        self.repo.update_file(file_path, message, new_content.encode(), file.sha)

    def create_file(self, file_path, content='', message="Create new file"):
        # 或者创建新文件
        self.repo.create_file(file_path, message, content.encode())


if __name__ == '__main__':
    # 整理短信數據
    msg = input("请输入数据：")
    print("您输入的数据是：", msg)
    msg_tidy = format_trade_info(msg)
    MyNotebookGithubUpdate().update_me_md(file_path="me.md", content=msg_tidy)
