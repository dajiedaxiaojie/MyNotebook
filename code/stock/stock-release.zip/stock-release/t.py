import re
from datetime import datetime
from history import msg, msg_web


def extract_trade_info(text):
    # 定义正则表达式模式
    buy_pattern = r"(\d{2}:\d{2}:\d{2})委托买入(.*?)\((\d+)\),仓位约为(\d+\.\d+)%，委托价(\d+\.\d+)元，数量(\d+)股"
    sell_pattern = r"(\d{2}:\d{2}:\d{2})委托卖出(.*?)\((\d+)\),仓位约为(\d+\.\d+)%，委托价(\d+\.\d+)元，数量(\d+)股"

    # 查找买入信息
    person = '王军' if '王军' in text else '张浩'
    buy_match = re.search(buy_pattern, text)
    if buy_match:
        buy_time = buy_match.group(1)
        buy_stock = buy_match.group(2)
        buy_code = buy_match.group(3)
        buy_position = buy_match.group(4)
        buy_price = buy_match.group(5)
        buy_quantity = buy_match.group(6)
        buy_info = {
            "person": person,
            "type": "买入",
            "时间": buy_time,
            "股票": buy_stock,
            "代码": buy_code,
            "仓位": str(buy_position) + '%',
            "价格": buy_price,
            "数量": buy_quantity
        }
    else:
        buy_info = None

    # 查找卖出信息
    sell_match = re.search(sell_pattern, text)
    if sell_match:
        sell_time = sell_match.group(1)
        sell_stock = sell_match.group(2)
        sell_code = sell_match.group(3)
        sell_position = sell_match.group(4)
        sell_price = sell_match.group(5)
        sell_quantity = sell_match.group(6)
        sell_info = {
            "person": person,
            "type": "卖出",
            "时间": sell_time,
            "股票": sell_stock,
            "代码": sell_code,
            "仓位": str(sell_position) + '%',
            "价格": sell_price,
            "数量": sell_quantity
        }
    else:
        sell_info = None

    return buy_info, sell_info


def _format_trade_info(text, formatted_date):
    buy_info, sell_info = extract_trade_info(text)
    if buy_info:
        msg = f"|{buy_info['股票']}|{buy_info['代码']}|{formatted_date}|{buy_info['价格']}|{buy_info['仓位']}||||{buy_info['person']}|"
        flag = True
    elif sell_info:
        msg = f"|{sell_info['股票']}|{sell_info['代码']}||||{formatted_date}|{sell_info['价格']}|{sell_info['仓位']}|{sell_info['person']}|"
        flag = True
    else:
        msg = text
        flag = False
    return msg, flag


def format_trade_info(msgs):
    msg_tidy = ''
    formatted_date = datetime.now().strftime("%m/%d")
    for msg_sub in msgs.split('【华安证券】'):
        if "新股申购" not in msg_sub and "委托" in msg_sub:
            new_msg_sub, flag = _format_trade_info(msg_sub, formatted_date)
            if flag:
                msg_tidy += new_msg_sub + '\n'
    return msg_tidy


def parse_data(msg):
    lines = [line.strip() for line in msg.strip().split('\n')]
    data = []
    for line in lines:
        parts = line.strip('|').split('|')
        parts = [p.strip() for p in parts]
        stock, code, time_in, price_in, rate_in, time_out, price_out, rate_out, person = (parts + [''] * 8)[
                                                                                         :9]  # Pad with empty strings

        data.append({
            'stock': stock,
            'code': code,
            'time_in': time_in,
            'price_in': price_in,
            'rate_in': rate_in,
            'time_out': time_out,
            'price_out': price_out,
            'rate_out': rate_out,
            'person': person
        })
    return data

def remove_duplicates(data):
    seen = set()
    result = []
    for item in data:
        item_tuple = tuple(sorted(item.items()))
        if item_tuple not in seen:
            seen.add(item_tuple)
            result.append(item)
    return result

def sort_data(data):
    def sorting_key(item):
        # Prioritize stocks that haven't been sold yet
        is_sold = bool(item['time_out'])
        time_in = item['time_in'] or '9999-12-31'  # Default to a future date if time_in is empty
        time_out = item['time_out'] or '9999-12-31'
        return (item['stock'], time_in, time_out, is_sold)

    return sorted(data, key=sorting_key)


def format_data(data):
    output = ''
    for item in data:
        tmp=f"|{item['stock']}|{item['code']}|{item['time_in']}|{item['price_in']}|{item['rate_in']}|{item['time_out']}|{item['price_out']}|{item['rate_out']}|{item['person']}|\n"
        if tmp.replace('|','').replace('\n','')!='':
            output += tmp
    return output


def tidy_web_data(data):
    data = parse_data(data)
    data = remove_duplicates(data)
    sorted_data = sort_data(data)
    msg_web = format_data(sorted_data)
    return msg_web


if __name__ == '__main__':
    # 整理短信數據
    print(format_trade_info(msg))

    # # # 整理web數據
    print(tidy_web_data(data=msg_web))
